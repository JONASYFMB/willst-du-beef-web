/* Offline-Grundgerüst: App-Dateien werden gespeichert, Karten/Server-Daten nicht. Neue Version -> VERSION erhöhen. */
const VERSION = "wdb-web-1";
const DATEIEN = ["./", "index.html", "app.js", "kern.js", "leaflet.js", "leaflet.css", "icon-192.png", "apple-touch-icon.png", "manifest.webmanifest"];
self.addEventListener("install", (e) => { e.waitUntil(caches.open(VERSION).then((c) => c.addAll(DATEIEN))); self.skipWaiting(); });
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((n) => n !== VERSION).map((n) => caches.delete(n)))));
  self.clients.claim();
});
self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== location.origin) return; // Karten, OSM, ntfy: immer live
  // Erst Netz (damit Updates sofort ankommen), sonst gespeicherte Version
  e.respondWith(fetch(e.request).then((a) => { const k = a.clone(); caches.open(VERSION).then((c) => c.put(e.request, k)); return a; })
    .catch(() => caches.match(e.request)));
});
