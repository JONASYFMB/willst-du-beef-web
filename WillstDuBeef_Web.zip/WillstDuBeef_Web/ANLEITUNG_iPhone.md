# Willst du Beef – iPhone-Version (Web-App)

Ein iPhone kann keine Android-App (APK) installieren. Diese Version läuft deshalb in **Safari** und wird wie eine App auf den Home-Bildschirm gelegt. Sie ist **gratis**, ohne App Store und ohne Mac.

## Was sie kann
- Karte mit allen Burgerläden im sichtbaren Bereich (OpenStreetMap). Beim Verschieben werden sie automatisch markiert.
- Laden antippen: genaue Adresse (zum Kopieren), Reisezeit für 🚗 🚶 🚲 🚆, Navigation mit Apple Karten, Öffnungszeiten, Zusatzinfos, eigene Sterne und „⭐ Bewertungen & Fotos“.
- 👥 Freunde mit Namen und Figur-Farbe. **Dieselben Freundes-Codes wie in der Android-App**, iPhone und Android sehen sich also gegenseitig.

## Unterschied zur Android-App (ehrlich)
- **Standort teilen geht nur, solange die Web-App offen ist.** Apple erlaubt Web-Apps kein Teilen im Hintergrund. Deine Freunde sehen sonst den letzten Standort mit Uhrzeit, die Figur wird nach 30 Minuten blass.
- Kein Laden ganzer Länder auf einmal. Die Web-App lädt immer den sichtbaren Kartenausschnitt.
- Die Liste zeigt die Luftlinie. Die genauen Reisezeiten erscheinen beim Antippen eines Ladens.

## Veröffentlichen (einmalig, am Handy in Chrome)
1. **github.com/new** öffnen → Name `willst-du-beef-web` → **Public** (öffentlich, sonst ist GitHub Pages kostenpflichtig) → **Create repository**.
   Im Code sind keine Zugangsdaten oder Schlüssel, nur die App selbst.
2. **„creating a new file“** antippen → Name `.github/workflows/web.yml` → Inhalt aus dieser ZIP (`.github/workflows/web.yml`) oder aus meiner Chat-Nachricht einfügen → **Commit changes**.
3. **Settings → Pages** → bei **Source** **„GitHub Actions“** wählen.
4. **Add file → Upload files** → `WillstDuBeef_Web.zip` (nicht entpacken) → **Commit changes**.
5. Unter **More → Actions** auf den grünen Haken warten. Deine Adresse ist dann:
   **https://jonasyfmb.github.io/willst-du-beef-web/**

## Am iPhone installieren (dein Freund)
1. Den Link in **Safari** öffnen.
2. Unten auf **Teilen ⬆︎** tippen → **„Zum Home-Bildschirm“** → **Hinzufügen**.
3. Die App über das neue Symbol öffnen und **Standort erlauben**.
   Falls er versehentlich „Nicht erlauben“ getippt hat: **Einstellungen → Datenschutz & Sicherheit → Ortungsdienste → Safari-Websites → „Beim Verwenden der App“**.
4. 👥 → Name und Farbe → Codes austauschen wie bei Android.

## Updates
Neue `WillstDuBeef_Web.zip` hochladen. Nach dem grünen Haken hat dein Freund beim nächsten Öffnen automatisch die neue Version.

## Tests
- 7 automatische Tests für die Logik (simulierte Server).
- Ein Kreuztest mit der Android-App: Codes und verschlüsselte Standorte funktionieren in beide Richtungen.
- Ein Durchlauf in Chrome mit iPhone-Ansicht und nachgebildeten Servern: Burger, Details, Freunde, eigene Figur, keine Fehler.
- **Nicht getestet:** auf einem echten iPhone und mit den echten Servern. Das passiert erst, wenn die Seite online ist.
