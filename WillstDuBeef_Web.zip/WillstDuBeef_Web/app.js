/* Willst du Beef – Web-App-Oberfläche (iPhone & alle Browser). */
(function () {
  "use strict";
  const K = window.Kern;
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const lesen = (k, d) => { try { const v = localStorage.getItem("wdb_" + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } };
  const schreiben = (k, v) => { try { localStorage.setItem("wdb_" + k, JSON.stringify(v)); } catch (e) {} };

  // ---------------- Zustand ----------------
  let standort = null, standortGenau = null;
  let laeden = lesen("laeden", []);
  let auswahl = null;
  let geladen = null;           // Bereich, der schon geladen ist
  let laedtBereich = false, letzteSuche = 0;
  const adressen = {}, zeiten = {};
  let ich = lesen("ich", null), freunde = lesen("freunde", []), orte = lesen("orte", {});
  let teilen = lesen("teilen", false);
  let letzteFreundAbfrage = 0;

  // ---------------- Hinweis (verschwindet von selbst) ----------------
  let hinweisTimer = null;
  function hinweis(text) {
    const h = $("#hinweis"); h.textContent = text; h.style.display = "block";
    clearTimeout(hinweisTimer); hinweisTimer = setTimeout(() => (h.style.display = "none"), 3500);
  }
  $("#hinweis").onclick = () => ($("#hinweis").style.display = "none");
  const ladeAnzeige = () => ($("#laedt").style.display = laedtBereich ? "block" : "none");

  // ---------------- Karte ----------------
  const ansicht = lesen("ansicht", { lat: 48.2082, lng: 16.3738, z: 13 });
  const karte = L.map("karte", { zoomControl: false, attributionControl: true }).setView([ansicht.lat, ansicht.lng], ansicht.z);
  L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: "© OpenStreetMap-Mitwirkende" }).addTo(karte);
  karte.attributionControl.setPrefix(false);

  const burgerIcon = L.divIcon({ className: "burger", html: "🍔", iconSize: [30, 30] });
  const burgerAktiv = L.divIcon({ className: "burger aktiv", html: "🍔", iconSize: [42, 42] });
  const marker = new Map();

  // ---------------- Figur (gleiches Männchen wie in der Android-App) ----------------
  const figurCache = new Map();
  function figur(css, name, blass) {
    const key = css + "|" + (name || "") + "|" + !!blass;
    if (figurCache.has(key)) return figurCache.get(key);
    const r = window.devicePixelRatio || 2, c = document.createElement("canvas"), g = c.getContext("2d");
    g.font = "bold 12px -apple-system, sans-serif";
    const schildB = name ? g.measureText(name).width + 14 : 0, schildH = name ? 21 : 0;
    const w = Math.ceil(Math.max(28, schildB)) + 2, h = schildH + 41;
    c.width = w * r; c.height = h * r; g.scale(r, r); g.globalAlpha = blass ? 0.5 : 1;
    const m = w / 2;
    const rund = (x1, y1, x2, y2, rad) => { g.beginPath(); g.roundRect(x1, y1, x2 - x1, y2 - y1, rad); };
    if (name) {
      rund(m - schildB / 2, 1, m + schildB / 2, 18, 9); g.fillStyle = "#fff"; g.fill(); g.lineWidth = 2; g.strokeStyle = css; g.stroke();
      g.fillStyle = "#222"; g.font = "bold 12px -apple-system, sans-serif"; g.textAlign = "center"; g.fillText(name, m, 14);
    }
    const y = schildH;
    g.lineWidth = 1.6; g.strokeStyle = "#333"; g.fillStyle = css;
    const form = (x1, y1, x2, y2, rad) => { rund(x1, y1, x2, y2, rad); g.fill(); g.stroke(); };
    form(m - 7, y + 25, m - 1, y + 39, 3); form(m + 1, y + 25, m + 7, y + 39, 3); form(m - 9.5, y + 13, m + 9.5, y + 30, 6);
    g.beginPath(); g.arc(m, y + 7.5, 6.5, 0, Math.PI * 2); g.fill(); g.stroke();
    g.fillStyle = "#222"; g.beginPath(); g.arc(m - 2.3, y + 7, 1.1, 0, Math.PI * 2); g.arc(m + 2.3, y + 7, 1.1, 0, Math.PI * 2); g.fill();
    const icon = { url: c.toDataURL(), w, h, fussY: schildH + 39 };
    figurCache.set(key, icon);
    return icon;
  }
  const figurIcon = (css, name, blass) => {
    const f = figur(css, name, blass);
    return L.icon({ iconUrl: f.url, iconSize: [f.w, f.h], iconAnchor: [f.w / 2, f.fussY], popupAnchor: [0, -f.fussY + 4] });
  };
  const meineFarbe = () => K.farbeVon(ich ? ich.farbe : null).css;

  // ---------------- Eigener Standort (flüssig gleitende Figur) ----------------
  let ichMarker = null, genauKreis = null, ersterFix = true, animation = null;
  function standortZeigen(lat, lng, genau) {
    if (!ichMarker) {
      ichMarker = L.marker([lat, lng], { icon: figurIcon(meineFarbe()), zIndexOffset: 2000, interactive: false }).addTo(karte);
      genauKreis = L.circle([lat, lng], { radius: genau || 0, color: "#4A90E2", weight: 1, fillOpacity: 0.12, interactive: false }).addTo(karte);
      return;
    }
    const von = ichMarker.getLatLng(), start = performance.now(), dauerMs = 600;
    cancelAnimationFrame(animation);
    const schritt = (t) => {
      const f = Math.min(1, (t - start) / dauerMs);
      const p = [von.lat + (lat - von.lat) * f, von.lng + (lng - von.lng) * f];
      ichMarker.setLatLng(p); genauKreis.setLatLng(p);
      if (f < 1) animation = requestAnimationFrame(schritt);
    };
    animation = requestAnimationFrame(schritt);
    genauKreis.setRadius(genau || 0);
  }
  function ortungStarten() {
    if (!navigator.geolocation) { hinweis("Dieses Gerät kann keinen Standort liefern."); return; }
    navigator.geolocation.watchPosition((p) => {
      standort = { lat: p.coords.latitude, lng: p.coords.longitude }; standortGenau = p.coords.accuracy;
      standortZeigen(standort.lat, standort.lng, standortGenau);
      if (ersterFix) { ersterFix = false; karte.setView([standort.lat, standort.lng], 15); zeichnen(); }
      eigenenStandortSenden();
    }, (e) => {
      if (e.code === 1) hinweis("Standort nicht erlaubt. iPhone: Einstellungen → Datenschutz → Ortungsdienste → Safari-Websites → „Beim Verwenden“.");
    }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 30000 });
  }
  $("#inDerNaehe").onclick = () => {
    if (standort) karte.setView([standort.lat, standort.lng], 15);
    else { hinweis("Suche deinen Standort …"); ersterFix = true; ortungStarten(); }
  };

  // ---------------- Burgerläden laden (sichtbarer Bereich, still bei Fehlern) ----------------
  function sichtBereich() {
    const b = karte.getBounds();
    return { sued: b.getSouth(), west: b.getWest(), nord: b.getNorth(), ost: b.getEast() };
  }
  const enthaelt = (a, b) => a && b.sued >= a.sued && b.nord <= a.nord && b.west >= a.west && b.ost <= a.ost;
  const groesser = (b, f) => { const dl = (b.nord - b.sued) * (f - 1) / 2, dg = (b.ost - b.west) * (f - 1) / 2;
    return { sued: b.sued - dl, west: b.west - dg, nord: b.nord + dl, ost: b.ost + dg }; };

  function uebernehmen(neu) {
    const m = new Map(laeden.map((l) => [l.id, l]));
    neu.forEach((n) => { const a = m.get(n.id); m.set(n.id, a && !n.adresse ? { ...n, adresse: a.adresse } : n); });
    let alle = [...m.values()];
    if (alle.length > 800) { const c = karte.getCenter(); alle = alle.sort((a, b) => K.luftlinieM(c, a.ort) - K.luftlinieM(c, b.ort)).slice(0, 800); }
    laeden = alle; schreiben("laeden", laeden);
    zeichnen();
  }

  async function bereichLaden(wiederholung) {
    if (karte.getZoom() < 12) { $("#zoomHinweis").style.display = "block"; return; }
    $("#zoomHinweis").style.display = "none";
    const sicht = sichtBereich();
    if (enthaelt(geladen, sicht) || laedtBereich) return;
    const warten = 1500 - (Date.now() - letzteSuche);
    if (warten > 0) { setTimeout(() => bereichLaden(), warten + 50); return; }
    letzteSuche = Date.now();
    const ziel = groesser(sicht, 1.4);
    laedtBereich = true; ladeAnzeige();
    try {
      const j = await K.overpassHolen(K.bereichAbfrage(ziel));
      geladen = ziel; uebernehmen(K.overpassLesen(j));
      setTimeout(() => bereichLaden(), 1600); // falls inzwischen weitergeschoben
    } catch (e) {
      if (!wiederholung) setTimeout(() => bereichLaden(true), 4000);
    } finally { laedtBereich = false; ladeAnzeige(); }
  }
  let bewegtTimer = null;
  karte.on("moveend", () => {
    const c = karte.getCenter(); schreiben("ansicht", { lat: c.lat, lng: c.lng, z: karte.getZoom() });
    clearTimeout(bewegtTimer); bewegtTimer = setTimeout(() => bereichLaden(), 700);
  });

  // ---------------- Stadtsuche ----------------
  $("#suche").onsubmit = async (ev) => {
    ev.preventDefault();
    const text = $("#suchtext").value.trim(); if (!text) return;
    $("#suchtext").blur();
    try {
      const a = await fetch("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&accept-language=de&q=" + encodeURIComponent(text));
      const j = await a.json();
      if (!j[0]) { hinweis("„" + text + "“ nicht gefunden."); return; }
      karte.setView([+j[0].lat, +j[0].lon], 14);
    } catch (e) { hinweis("Keine Verbindung – bitte nochmal."); }
  };

  // ---------------- Zeichnen: Marker + Liste ----------------
  function zeichnen() {
    $("#anzahl").textContent = "🍔 " + laeden.length;
    const ids = new Set(laeden.map((l) => l.id));
    for (const [id, m] of marker) if (!ids.has(id)) { karte.removeLayer(m); marker.delete(id); }
    for (const l of laeden) {
      let m = marker.get(l.id);
      if (!m) {
        m = L.marker([l.ort.lat, l.ort.lng], { icon: burgerIcon }).addTo(karte);
        m.on("click", () => auswaehlen(l.id, true));
        marker.set(l.id, m);
      }
      const soll = l.id === auswahl ? burgerAktiv : burgerIcon;
      if (m.options.icon !== soll) { m.setIcon(soll); m.setZIndexOffset(l.id === auswahl ? 1000 : 0); }
    }
    listeZeichnen();
  }

  const meineSterne = (id) => lesen("bew_" + id, 0);
  const sterneText = (n) => (n ? "★".repeat(n) + "☆".repeat(5 - n) : "");

  function listeZeichnen() {
    const bezug = standort || karte.getCenter();
    const sortiert = [...laeden].sort((a, b) => K.luftlinieM(bezug, a.ort) - K.luftlinieM(bezug, b.ort));
    const g = laeden.find((l) => l.id === auswahl);
    let html = g ? detailHtml(g) : "";
    if (!laeden.length) html += '<p class="klein braun" style="padding:12px">Karte verschieben oder Stadt suchen – Burgerläden erscheinen automatisch als 🍔.</p>';
    html += sortiert.slice(0, 150).map((l) => {
      const adr = l.adresse || adressen[l.id] || "";
      return '<div class="zeile' + (l.id === auswahl ? " aktiv" : "") + '" data-id="' + esc(l.id) + '"><div class="reihe"><b style="flex:1">' + esc(l.name) +
        '</b><span style="color:#E6A100">' + sterneText(meineSterne(l.id)) + '</span></div>' +
        '<div class="klein">📍 ' + esc(adr || "Adresse: antippen") + '</div>' +
        '<div class="klein braun">📏 ' + K.distanz(K.luftlinieM(bezug, l.ort)) + (standort ? " Luftlinie · antippen für Reisezeit" : " von der Kartenmitte") + '</div></div>';
    }).join("");
    $("#liste").innerHTML = html;
  }

  function detailHtml(l) {
    const adr = l.adresse || adressen[l.id] || "";
    const z = zeiten[l.id];
    let wege;
    if (!standort) wege = '<p class="klein">Für Reisezeiten bitte Standort erlauben („📍 In meiner Nähe“).</p>';
    else if (!z) wege = '<p class="klein">⏳ Berechne Reisezeiten …</p>';
    else wege = K.MODI.map((m) => '<a class="modus" target="_blank" rel="noopener" href="' + esc(K.navigationsLink(l, m)) + '"><span>' + m.symbol + " " + m.name +
      "</span><b>" + K.dauer(z[m.key].sek, z[m.key].geschaetzt) + " · " + K.distanz(z[m.key].m) + "</b><i>Los ›</i></a>").join("");
    const s = meineSterne(l.id);
    return '<div class="detail"><div class="reihe"><span style="font-size:26px">🍔</span><h2>' + esc(l.name) + '</h2><button id="detailZu" style="background:none;border:0;font-size:20px">✕</button></div>' +
      '<div class="klein" style="margin-top:6px;color:#888">Adresse</div><div class="reihe"><b style="flex:1;font-size:16px">' + esc(adr || "wird gesucht …") + '</b>' +
      (adr ? '<button class="knopf hell" id="kopieren">📋 Kopieren</button>' : "") + "</div>" +
      (l.zeiten ? '<div class="klein" style="margin-top:4px">🕒 ' + esc(l.zeiten) + "</div>" : "") +
      (l.infos && l.infos.length ? '<div class="chips">' + l.infos.map((i) => '<span class="chip">' + esc(i) + "</span>").join("") + "</div>" : "") +
      '<div class="klein" style="margin-top:12px;color:#888">Wie lange brauche ich? (antippen = Navigation)</div>' + wege +
      '<div class="reihe sterne" style="margin-top:10px"><span class="klein" style="font-size:13px;color:#333">Meine Bewertung:</span>' +
      [1, 2, 3, 4, 5].map((n) => '<span data-stern="' + n + '">' + (s >= n ? "★" : "☆") + "</span>").join("") + "</div>" +
      '<div class="knopfe"><button class="knopf" id="bewertungen">⭐ Bewertungen & Fotos</button>' +
      (l.web ? '<a class="knopf hell" style="text-decoration:none" target="_blank" rel="noopener" href="' + esc(/^https?:/.test(l.web) ? l.web : "https://" + l.web) + '">🌐 Webseite</a>' : "") +
      (l.tel ? '<a class="knopf hell" style="text-decoration:none" href="tel:' + esc(l.tel.replace(/\s/g, "")) + '">📞 Anrufen</a>' : "") + "</div></div>";
  }

  $("#liste").addEventListener("click", (ev) => {
    const g = laeden.find((l) => l.id === auswahl);
    const t = ev.target;
    if (t.id === "detailZu") { auswahl = null; zeichnen(); return; }
    if (t.id === "kopieren" && g) { navigator.clipboard?.writeText(g.adresse || adressen[g.id] || "").then(() => hinweis("Adresse kopiert."), () => {}); return; }
    if (t.id === "bewertungen" && g) { window.open(K.bewertungenSuche(g, g.adresse || adressen[g.id]), "_blank", "noopener"); return; }
    if (t.dataset && t.dataset.stern && g) { const n = +t.dataset.stern; schreiben("bew_" + g.id, meineSterne(g.id) === n ? 0 : n); listeZeichnen(); return; }
    const zeile = t.closest(".zeile");
    if (zeile) auswaehlen(zeile.dataset.id, false);
  });

  async function auswaehlen(id, vonKarte) {
    auswahl = id; zeichnen();
    $("#liste").scrollTop = 0;
    const l = laeden.find((x) => x.id === id); if (!l) return;
    if (!vonKarte) karte.panTo([l.ort.lat, l.ort.lng]);
    if (!l.adresse && !adressen[id]) {
      try {
        const a = await fetch("https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&addressdetails=1&accept-language=de&lat=" +
          l.ort.lat.toFixed(6) + "&lon=" + l.ort.lng.toFixed(6));
        const adr = K.adresseLesen(await a.json()); if (adr) adressen[id] = adr;
      } catch (e) {}
      if (auswahl === id) listeZeichnen();
    }
    if (standort && !zeiten[id]) {
      const z = {};
      for (const m of K.MODI) z[m.key] = await K.route(standort, l.ort, m);
      zeiten[id] = z;
      if (auswahl === id) listeZeichnen();
    }
  }

  // ---------------- Freunde ----------------
  const freundMarker = new Map();
  function freundeZeichnen() {
    const jetzt = Date.now();
    const da = new Set();
    for (const p of freunde) {
      const o = orte[p.kanal]; if (!o) continue;
      da.add(p.kanal);
      const blass = jetzt - o.zeitMs > 30 * 60000, css = K.farbeVon(p.farbe).css;
      let m = freundMarker.get(p.kanal);
      if (!m) { m = L.marker([o.ort.lat, o.ort.lng], { zIndexOffset: 1500, icon: figurIcon(css, p.name, blass) }).addTo(karte); m._schl = p.name + css + blass; freundMarker.set(p.kanal, m); }
      const schl = p.name + css + blass;
      if (m._schl !== schl) { m.setIcon(figurIcon(css, p.name, blass)); m._schl = schl; }
      m.setLatLng([o.ort.lat, o.ort.lng]);
      m.bindPopup("<b>" + esc(p.name) + "</b><br>Zuletzt " + K.zeitVor(o.zeitMs, jetzt) +
        (standort ? " · " + K.distanz(K.luftlinieM(standort, o.ort)) + " entfernt" : ""));
    }
    for (const [k, m] of freundMarker) if (!da.has(k)) { karte.removeLayer(m); freundMarker.delete(k); }
  }

  function orteUebernehmen(neu) {
    let geaendert = false;
    for (const [k, f] of Object.entries(neu)) {
      if (!orte[k] || orte[k].zeitMs <= f.zeitMs) { orte[k] = { ort: f.ort, zeitMs: f.zeitMs, genauM: f.genauM }; geaendert = true; }
      const p = freunde.find((x) => x.kanal === k);
      if (p && f.farbe != null && f.farbe !== p.farbe) { p.farbe = f.farbe; schreiben("freunde", freunde); }
    }
    if (geaendert) { schreiben("orte", orte); freundeZeichnen(); if (freundeOffen) freundeAnsicht(); }
  }

  async function freundeAbfragen() {
    if (!freunde.length || document.hidden) return;
    const jetztSek = Math.floor(Date.now() / 1000);
    try {
      if (!letzteFreundAbfrage) {
        const erg = {};
        for (const f of freunde) { try { const o = await K.neueste(f); if (o) erg[f.kanal] = o; } catch (e) {} }
        orteUebernehmen(erg);
      } else orteUebernehmen(await K.seit(freunde, letzteFreundAbfrage - 90));
      letzteFreundAbfrage = jetztSek;
    } catch (e) {}
  }
  setInterval(freundeAbfragen, 30000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) { freundeAbfragen(); eigenenStandortSenden(); } });

  let sendetGerade = false;
  async function eigenenStandortSenden() {
    if (!teilen || !ich || !standort || document.hidden || sendetGerade) return;
    const jetzt = Date.now(), tag = Math.floor(jetzt / 86400000);
    const s = lesen("senden", {});
    const heute = s.tag === tag ? s.anzahl || 0 : 0;
    if (!K.sollSenden(s.zeit, s.ort, jetzt, standort, heute, s.pauseBis)) return;
    sendetGerade = true;
    try {
      await K.senden(ich, standort, standortGenau, jetzt);
      schreiben("senden", { zeit: jetzt, ort: standort, tag, anzahl: heute + 1 });
    } catch (e) {
      schreiben("senden", { ...s, pauseBis: jetzt + (e.message === "Limit erreicht" ? 1800000 : 60000) });
    } finally { sendetGerade = false; }
  }
  const baldSenden = () => { const s = lesen("senden", {}); delete s.zeit; delete s.ort; schreiben("senden", s); eigenenStandortSenden(); };

  // ---------------- Freunde-Bildschirm ----------------
  let freundeOffen = false, gewaehlteFarbe = null, meldung = null;
  function freundeAnsicht() {
    const farbe = gewaehlteFarbe ?? (ich ? ich.farbe : K.FARBEN[0].argb);
    const f = figur(K.farbeVon(farbe).css);
    let h = '<h3>' + (ich ? "Ich" : "Wie heißt du?") + '</h3><div class="reihe"><img src="' + f.url + '" style="width:30px" alt="">' +
      '<input type="text" id="meinName" maxlength="20" placeholder="Dein Name" value="' + esc(ich ? ich.name : "") + '"></div>' +
      '<div class="klein" style="margin-top:8px">Farbe deiner Figur:</div><div class="farben">' +
      K.FARBEN.map((x) => '<button data-farbe="' + x.argb + '" class="' + (x.argb === farbe ? "an" : "") + '" style="background:' + x.css + '" aria-label="' + x.name + '"></button>').join("") +
      '</div><div id="profilFehler" class="fehler"></div><button class="knopf" id="profilSpeichern">' + (ich ? "Speichern" : "Los geht's") + "</button>";
    if (ich) {
      h += '<div class="karte"><div class="reihe"><b style="flex:1">📡 Meinen Standort mit Freunden teilen</b><label class="schalter"><input type="checkbox" id="teilen"' +
        (teilen ? " checked" : "") + '><span></span></label></div><div class="klein" style="margin-top:6px">' +
        (teilen ? "An – solange diese App offen ist. (Apple erlaubt Web-Apps kein Teilen im Hintergrund; deine Freunde sehen sonst deinen letzten Standort mit Uhrzeit.)"
          : "Aus – niemand sieht, wo du bist.") + "</div></div>" +
        '<h3>Mein Freundes-Code</h3><div class="klein">Schick ihn an Freunde (z. B. WhatsApp). Wer ihn hat, sieht deinen Standort – also nur echten Freunden geben. Funktioniert mit iPhone und Android.</div>' +
        '<div class="knopfe"><button class="knopf" id="codeTeilen">📤 Code teilen</button><button class="knopf hell" id="codeKopieren">📋 Kopieren</button></div>' +
        '<h3>Freund hinzufügen</h3><div class="klein">Code von deinem Freund hier einfügen. Ihr seht euch, wenn ihr beide den Code des anderen hinzufügt.</div>' +
        '<textarea id="code" rows="3" placeholder="Code (beginnt mit WDB1.)" style="margin-top:6px"></textarea>' +
        '<div class="knopfe"><button class="knopf hell" id="einfuegen">📋 Einfügen</button><button class="knopf" id="hinzufuegen">➕ Hinzufügen</button></div>' +
        '<div id="codeMeldung" class="' + (meldung && meldung.gut ? "gut" : "fehler") + '">' + esc(meldung ? meldung.text : "") + "</div>" +
        "<h3>Meine Freunde (" + freunde.length + ")</h3>" +
        (freunde.length ? "" : '<div class="klein">Noch keine Freunde. Lass dir ihren Code schicken.</div>') +
        freunde.map((p) => {
          const o = orte[p.kanal], css = K.farbeVon(p.farbe).css;
          const info = !o ? "Noch kein Standort (teilt nicht oder hat dich nicht hinzugefügt)"
            : K.zeitVor(o.zeitMs) + (standort ? " · " + K.distanz(K.luftlinieM(standort, o.ort)) + " entfernt" : "");
          return '<div class="freund" style="border-color:' + css + '"><img src="' + figur(css, null, !o).url + '" alt=""><div><b>' + esc(p.name) +
            '</b><div class="klein braun">' + esc(info) + "</div></div>" + (o ? '<button data-zeigen="' + p.kanal + '">📍 Zeigen</button>' : "") +
            '<button data-weg="' + p.kanal + '">🗑️</button></div>';
        }).join("") +
        '<div style="margin-top:18px"><button class="knopf hell" id="erneuern">🔄 Meinen Code erneuern</button></div>' +
        '<div class="klein" style="margin-top:6px;color:#888">Danach sieht dich niemand mehr mit dem alten Code. Technik: Standorte gehen verschlüsselt über den kostenlosen Dienst ntfy.sh (dort max. 12 Std. gespeichert); nur wer deinen Code hat, kann sie lesen.</div>';
    }
    $("#freundeInhalt").innerHTML = h;
  }
  function freundeOeffnen(an) {
    freundeOffen = an; $("#freunde").style.display = an ? "flex" : "none";
    if (an) { gewaehlteFarbe = null; meldung = null; freundeAnsicht(); }
  }
  $("#freundeKnopf").onclick = () => freundeOeffnen(true);
  $("#freundeZu").onclick = () => freundeOeffnen(false);

  $("#freundeInhalt").addEventListener("click", async (ev) => {
    const t = ev.target.closest("button") || ev.target;
    if (t.dataset.farbe) { gewaehlteFarbe = +t.dataset.farbe; const n = $("#meinName").value; freundeAnsicht(); $("#meinName").value = n; return; }
    if (t.id === "profilSpeichern") {
      const name = $("#meinName").value.trim(), farbe = gewaehlteFarbe ?? (ich ? ich.farbe : K.FARBEN[0].argb);
      if (!name) { $("#profilFehler").textContent = "Bitte einen Namen eingeben."; return; }
      if (freunde.some((f) => f.name.toLowerCase() === name.toLowerCase())) { $("#profilFehler").textContent = "„" + name + "“ heißt schon ein Freund von dir – jeder Name nur einmal."; return; }
      ich = ich ? { ...ich, name, farbe } : K.neuesProfil(name, farbe);
      schreiben("ich", ich); gewaehlteFarbe = null;
      if (ichMarker) ichMarker.setIcon(figurIcon(meineFarbe()));
      baldSenden(); freundeAnsicht(); return;
    }
    if (t.id === "codeTeilen") {
      const text = "Füg mich bei „Willst du Beef“ als Freund hinzu 🍔\n" + K.codeErzeugen(ich);
      if (navigator.share) navigator.share({ text }).catch(() => {});
      else navigator.clipboard?.writeText(K.codeErzeugen(ich)).then(() => { meldung = { gut: true, text: "Dein Code ist kopiert." }; freundeAnsicht(); });
      return;
    }
    if (t.id === "codeKopieren") { navigator.clipboard?.writeText(K.codeErzeugen(ich)).then(() => { meldung = { gut: true, text: "Dein Code ist kopiert." }; freundeAnsicht(); }, () => {}); return; }
    if (t.id === "einfuegen") { try { $("#code").value = await navigator.clipboard.readText(); } catch (e) { hinweis("Bitte lange ins Feld tippen → Einsetzen."); } return; }
    if (t.id === "hinzufuegen") {
      try {
        const f = K.codeLesen($("#code").value);
        const fehler = K.pruefen(f, ich, freunde);
        if (fehler) meldung = { gut: false, text: fehler };
        else {
          freunde.push(f); schreiben("freunde", freunde); meldung = { gut: true, text: "Hinzugefügt ✔" };
          K.neueste(f).then((o) => o && orteUebernehmen({ [f.kanal]: o })).catch(() => {});
        }
      } catch (e) { meldung = { gut: false, text: e.message }; }
      freundeAnsicht(); return;
    }
    if (t.dataset.zeigen) { const o = orte[t.dataset.zeigen]; if (o) { freundeOeffnen(false); karte.setView([o.ort.lat, o.ort.lng], 16); } return; }
    if (t.dataset.weg) {
      const p = freunde.find((x) => x.kanal === t.dataset.weg);
      if (p && confirm(p.name + " entfernen?\nDamit " + p.name + " DICH nicht mehr sieht, danach „Code erneuern“.")) {
        freunde = freunde.filter((x) => x.kanal !== p.kanal); delete orte[p.kanal];
        schreiben("freunde", freunde); schreiben("orte", orte); freundeZeichnen(); freundeAnsicht();
      }
      return;
    }
    if (t.id === "erneuern" && confirm("Code erneuern?\nAlle mit deinem alten Code sehen dich nicht mehr. Schick danach den neuen Code an deine Freunde.")) {
      ich = K.neuesProfil(ich.name, ich.farbe); schreiben("ich", ich); baldSenden();
      meldung = { gut: true, text: "Neuer Code erstellt – jetzt teilen." }; freundeAnsicht();
    }
  });
  $("#freundeInhalt").addEventListener("change", (ev) => {
    if (ev.target.id !== "teilen") return;
    teilen = ev.target.checked; schreiben("teilen", teilen);
    if (teilen) { if (!standort) ortungStarten(); baldSenden(); }
    freundeAnsicht();
  });

  // ---------------- Start ----------------
  const istIOS = /iPhone|iPad|iPod/.test(navigator.userAgent);
  const installiert = window.matchMedia("(display-mode: standalone)").matches || navigator.standalone;
  if (istIOS && !installiert && !lesen("tippWeg", false)) $("#tipp").style.display = "block";
  $("#tippZu").onclick = () => { $("#tipp").style.display = "none"; schreiben("tippWeg", true); };
  if ("serviceWorker" in navigator && location.protocol === "https:") navigator.serviceWorker.register("sw.js").catch(() => {});

  zeichnen();
  freundeZeichnen();
  ortungStarten();
  setTimeout(() => bereichLaden(), 300);
  freundeAbfragen();
})();
