/* Willst du Beef – Web-App (für iPhone & alle Browser). Kern-Logik ohne Oberfläche.
 * Freundes-Codes und Verschlüsselung sind IDENTISCH zur Android-App, damit iPhone und Android sich gegenseitig sehen. */
(function (global) {
  "use strict";

  // ---------- Farben der Figur (gleiche Zahlen wie Android: ARGB als vorzeichenbehaftete 32-Bit-Zahl) ----------
  const FARBEN = [
    ["GELB", "Gelb", 0xFFFFC107], ["ROT", "Rot", 0xFFE53935], ["BLAU", "Blau", 0xFF1E88E5],
    ["GRUEN", "Grün", 0xFF43A047], ["LILA", "Lila", 0xFF8E24AA], ["ORANGE", "Orange", 0xFFFB8C00],
    ["PINK", "Pink", 0xFFEC407A], ["TUERKIS", "Türkis", 0xFF00ACC1], ["SCHWARZ", "Schwarz", 0xFF37474F],
  ].map(([key, name, v]) => ({ key, name, argb: v | 0, css: "#" + (v & 0xFFFFFF).toString(16).padStart(6, "0") }));
  const farbeVon = (argb) => FARBEN.find((f) => f.argb === argb) || FARBEN[0];

  // ---------- Base64 ----------
  const utf8 = new TextEncoder(), utf8d = new TextDecoder();
  function b64(bytes) { let s = ""; bytes.forEach((b) => (s += String.fromCharCode(b))); return btoa(s); }
  function unb64(str) { const s = atob(str); const a = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a; }
  const b64url = (bytes) => b64(bytes).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  function unb64url(str) {
    if (!/^[A-Za-z0-9_-]*$/.test(str)) throw new Error("kein base64url");
    let s = str.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "=";
    return unb64(s);
  }
  const zufall = (n) => crypto.getRandomValues(new Uint8Array(n));

  // ---------- Freundes-Code ----------
  const PRAEFIX = "WDB1.";
  function neuesProfil(name, argb) {
    const kanal = "wdb-" + Array.from(zufall(12), (b) => b.toString(16).padStart(2, "0")).join("");
    return { name: String(name).trim(), farbe: farbeVon(argb).argb, kanal, schluessel: b64url(zufall(32)) };
  }
  function codeErzeugen(p) {
    return PRAEFIX + b64url(utf8.encode(JSON.stringify({ n: p.name, f: p.farbe, k: p.kanal, s: p.schluessel })));
  }
  function codeLesen(text) {
    const m = /WDB1\.[A-Za-z0-9_-]+/.exec(String(text || ""));
    if (!m) throw new Error("Kein Freundes-Code gefunden. Er beginnt mit „WDB1.“");
    let j;
    try { j = JSON.parse(utf8d.decode(unb64url(m[0].slice(PRAEFIX.length)))); }
    catch (e) { throw new Error("Der Code ist unvollständig oder kaputt. Bitte nochmal ganz kopieren."); }
    const name = String(j.n || "").trim(), kanal = String(j.k || ""), s = String(j.s || "");
    let laenge = -1; try { laenge = unb64url(s).length; } catch (e) {}
    if (!name || !/^wdb-[0-9a-f]{24}$/.test(kanal) || laenge !== 32) throw new Error("Der Code ist ungültig.");
    return { name: name.slice(0, 30), farbe: farbeVon(typeof j.f === "number" ? j.f : null).argb, kanal, schluessel: s };
  }
  /** Jeder Name nur EINMAL. Rückgabe: Fehlertext oder null. */
  function pruefen(neu, ich, freunde) {
    const gleich = (a, b) => a.toLowerCase() === b.toLowerCase();
    if (ich && neu.kanal === ich.kanal) return "Das ist dein eigener Code.";
    if (freunde.some((f) => f.kanal === neu.kanal)) return neu.name + " ist schon in deiner Liste.";
    if (ich && gleich(neu.name, ich.name)) return "„" + neu.name + "“ heißt du selbst – Namen gibt es nur einmal.";
    if (freunde.some((f) => gleich(f.name, neu.name))) return "Den Namen „" + neu.name + "“ gibt es schon in deiner Liste. Jeder Name nur einmal.";
    if (freunde.length >= 20) return "Maximal 20 Freunde.";
    return null;
  }

  // ---------- Verschlüsselung (AES-256-GCM, 12-Byte-IV vorne, Standard-Base64) ----------
  async function schluesselObjekt(s) { return crypto.subtle.importKey("raw", unb64url(s), "AES-GCM", false, ["encrypt", "decrypt"]); }
  async function verschluesseln(text, s) {
    const iv = zufall(12);
    const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await schluesselObjekt(s), utf8.encode(text)));
    const alles = new Uint8Array(12 + ct.length); alles.set(iv); alles.set(ct, 12);
    return b64(alles);
  }
  async function entschluesseln(text, s) {
    try {
      const d = unb64(String(text).trim());
      const klar = await crypto.subtle.decrypt({ name: "AES-GCM", iv: d.slice(0, 12) }, await schluesselObjekt(s), d.slice(12));
      return utf8d.decode(klar);
    } catch (e) { return null; }
  }

  // ---------- Entfernung & Format ----------
  function luftlinieM(a, b) {
    const r = 6371000, rad = Math.PI / 180;
    const dLat = (b.lat - a.lat) * rad, dLng = (b.lng - a.lng) * rad;
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dLng / 2) ** 2;
    return Math.round(2 * r * Math.asin(Math.min(1, Math.sqrt(h))));
  }
  function dauer(sek, geschaetzt) {
    const min = Math.max(1, Math.round(sek / 60));
    const t = min < 60 ? min + " Min" : Math.floor(min / 60) + " Std " + (min % 60 ? (min % 60) + " Min" : "");
    return (geschaetzt ? "ca. " : "") + t.trim();
  }
  function distanz(m) {
    if (m == null) return "?";
    return m < 1000 ? m + " m" : (m / 1000).toFixed(m < 10000 ? 1 : 0).replace(".", ",") + " km";
  }
  function zeitVor(ms, jetzt) {
    const min = Math.max(0, Math.floor(((jetzt ?? Date.now()) - ms) / 60000));
    if (min < 1) return "gerade eben";
    if (min < 60) return "vor " + min + " Min.";
    if (min < 1440) return "vor " + Math.floor(min / 60) + " Std.";
    return "vor " + Math.floor(min / 1440) + " Tag(en)";
  }

  // ---------- Wann senden (sparsam, wie Android) ----------
  const REGEL = { BEWEGT_M: 50, BEWEGT_MS: 120000, RUHIG_MS: 900000, SPARGRENZE: 220, SPAR_MS: 1800000 };
  function sollSenden(letzteZeit, letzterOrt, jetzt, ort, heute, pauseBis) {
    if (jetzt < (pauseBis || 0)) return false;
    if (!letzteZeit || !letzterOrt) return true;
    const seit = jetzt - letzteZeit;
    if (heute >= REGEL.SPARGRENZE) return seit >= REGEL.SPAR_MS;
    return luftlinieM(letzterOrt, ort) >= REGEL.BEWEGT_M ? seit >= REGEL.BEWEGT_MS : seit >= REGEL.RUHIG_MS;
  }

  // ---------- ntfy (Weitergabe der Standorte) ----------
  const NTFY = "https://ntfy.sh";
  async function senden(ich, ort, genauM, jetzt, server, fetcher) {
    const f = fetcher || fetch;
    const inhalt = { a: ort.lat, o: ort.lng, z: jetzt, n: ich.name, f: ich.farbe };
    if (genauM != null) inhalt.g = genauM;
    let a;
    try { a = await f((server || NTFY) + "/" + ich.kanal, { method: "POST", body: await verschluesseln(JSON.stringify(inhalt), ich.schluessel) }); }
    catch (e) { throw new Error("Keine Verbindung"); }
    if (a.status === 429) throw new Error("Limit erreicht");
    if (!a.ok) throw new Error("Teilen-Dienst Fehler " + a.status);
  }
  async function ntfyLesen(text, freunde) {
    const schl = new Map(freunde.map((f) => [f.kanal, f.schluessel]));
    const erg = {};
    for (const zeile of String(text).split("\n")) {
      if (!zeile.trim()) continue;
      let o; try { o = JSON.parse(zeile); } catch (e) { continue; }
      if (o.event !== "message" || !schl.has(o.topic)) continue;
      const klar = await entschluesseln(o.message || "", schl.get(o.topic));
      if (!klar) continue;
      let j; try { j = JSON.parse(klar); } catch (e) { continue; }
      if (typeof j.a !== "number" || typeof j.o !== "number" || Math.abs(j.a) > 90 || Math.abs(j.o) > 180) continue;
      const zeit = typeof o.time === "number" ? o.time * 1000 : j.z;
      if (typeof zeit !== "number") continue;
      const neu = { ort: { lat: j.a, lng: j.o }, genauM: typeof j.g === "number" ? j.g : null, zeitMs: zeit,
        name: typeof j.n === "string" ? j.n.slice(0, 30) : null, farbe: typeof j.f === "number" ? farbeVon(j.f).argb : null };
      if (!erg[o.topic] || erg[o.topic].zeitMs <= zeit) erg[o.topic] = neu;
    }
    return erg;
  }
  async function abholen(url, freunde, fetcher) {
    let a;
    try { a = await (fetcher || fetch)(url); } catch (e) { throw new Error("Keine Verbindung"); }
    if (a.status === 429) throw new Error("Limit erreicht");
    if (!a.ok) throw new Error("Teilen-Dienst Fehler " + a.status);
    return ntfyLesen(await a.text(), freunde);
  }
  const neueste = (f, server, fetcher) => abholen((server || NTFY) + "/" + f.kanal + "/json?poll=1&since=latest", [f], fetcher).then((m) => m[f.kanal] || null);
  const seit = (freunde, seitSek, server, fetcher) => freunde.length
    ? abholen((server || NTFY) + "/" + freunde.map((f) => f.kanal).join(",") + "/json?poll=1&since=" + seitSek, freunde, fetcher)
    : Promise.resolve({});

  // ---------- OpenStreetMap: Burgerläden ----------
  const OVERPASS = ["https://overpass-api.de/api/interpreter", "https://overpass.private.coffee/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter"];
  function bereichAbfrage(b) {
    const box = [b.sued, b.west, b.nord, b.ost].map((x) => x.toFixed(6)).join(",");
    return '[out:json][timeout:20];nwr["amenity"~"^(fast_food|restaurant)$"](' + box + ')->.a;' +
      '(nwr.a["cuisine"~"burger",i];nwr.a["name"~"burger",i];);out center tags qt 400;';
  }
  function infosLesen(t) {
    const ja = (k) => ["yes", "only", "designated"].includes(String(t[k] || "").toLowerCase());
    const r = [];
    if (t.amenity === "fast_food") r.push("🍟 Fast Food"); else if (t.amenity === "restaurant") r.push("🍽️ Restaurant");
    if (t.brand && t.brand !== t.name) r.push("🏷️ " + t.brand);
    if (ja("delivery")) r.push("🛵 Lieferung");
    if (ja("takeaway")) r.push("🥡 Zum Mitnehmen");
    if (ja("drive_through")) r.push("🚗 Drive-in");
    if (ja("diet:vegan")) r.push("🌱 Vegan"); else if (ja("diet:vegetarian")) r.push("🥗 Vegetarisch");
    if (ja("diet:halal")) r.push("☪️ Halal");
    if (ja("diet:gluten_free")) r.push("🌾 Glutenfrei");
    if (ja("outdoor_seating")) r.push("☀️ Sitzplätze draußen");
    if (t.wheelchair === "yes") r.push("♿ Rollstuhlgerecht"); else if (t.wheelchair === "limited") r.push("♿ Teilweise rollstuhlgerecht");
    if (ja("payment:cards") || ja("payment:credit_cards") || ja("payment:debit_cards")) r.push("💳 Kartenzahlung");
    if (ja("internet_access") || t.internet_access === "wlan" || t.internet_access === "wifi") r.push("📶 WLAN");
    return r;
  }
  function overpassLesen(json) {
    const gesehen = new Set(), erg = [];
    for (const e of (json && json.elements) || []) {
      if (!e.type || e.id == null) continue;
      const id = e.type + "/" + e.id;
      if (gesehen.has(id)) continue; gesehen.add(id);
      const lat = e.lat ?? (e.center && e.center.lat), lng = e.lon ?? (e.center && e.center.lon);
      if (typeof lat !== "number" || typeof lng !== "number") continue;
      const t = e.tags || {};
      const strasse = [t["addr:street"], t["addr:housenumber"]].filter(Boolean).join(" ");
      const stadt = [t["addr:postcode"], t["addr:city"]].filter(Boolean).join(" ");
      erg.push({ id, name: t.name || t.brand || "Burgerladen (ohne Namen)", ort: { lat, lng },
        adresse: [strasse, stadt].filter(Boolean).join(", "), zeiten: t.opening_hours || null,
        web: t.website || t["contact:website"] || null, tel: t.phone || t["contact:phone"] || null, infos: infosLesen(t) });
    }
    return erg;
  }
  async function overpassHolen(abfrage, fetcher, server) {
    const liste = server ? [server] : OVERPASS;
    let fehler = null;
    for (let i = 0; i < liste.length; i++) {
      const s = liste[(overpassHolen.bester + i) % liste.length] || liste[i];
      try {
        const a = await (fetcher || fetch)(s + "?data=" + encodeURIComponent(abfrage));
        if (a.status === 429 || a.status >= 500) throw new Error("überlastet");
        if (!a.ok) throw new Error("Fehler " + a.status);
        const j = await a.json();
        if (j.remark && /runtime error/.test(j.remark)) throw new Error("überlastet");
        overpassHolen.bester = (overpassHolen.bester + i) % liste.length;
        return j;
      } catch (e) { fehler = e; }
    }
    throw fehler || new Error("nicht erreichbar");
  }
  overpassHolen.bester = 0;

  function adresseLesen(j) {
    const a = (j && j.address) || {};
    const strasse = [a.road || a.pedestrian || a.square, a.house_number].filter(Boolean).join(" ");
    const stadt = [a.postcode, a.city || a.town || a.village || a.municipality].filter(Boolean).join(" ");
    const teile = [strasse, stadt].filter(Boolean);
    if (teile.length) { if (a.country) teile.push(a.country); return teile.join(", "); }
    return (j && j.display_name) || null;
  }

  const MODI = [
    { key: "AUTO", name: "Auto", symbol: "🚗", profil: "routed-car", kmh: 30, apple: "d" },
    { key: "ZU_FUSS", name: "Zu Fuß", symbol: "🚶", profil: "routed-foot", kmh: 4.8, apple: "w" },
    { key: "RAD", name: "Rad", symbol: "🚲", profil: "routed-bike", kmh: 15, apple: null },
    { key: "OEFFIS", name: "Öffis", symbol: "🚆", profil: null, kmh: 18, apple: "r" },
  ];
  async function route(start, ziel, modus, fetcher) {
    if (modus.profil) {
      try {
        const url = "https://routing.openstreetmap.de/" + modus.profil + "/route/v1/driving/" +
          start.lng.toFixed(6) + "," + start.lat.toFixed(6) + ";" + ziel.lng.toFixed(6) + "," + ziel.lat.toFixed(6) + "?overview=false";
        const a = await (fetcher || fetch)(url);
        const j = await a.json();
        if (j.code === "Ok" && j.routes && j.routes[0]) return { sek: Math.round(j.routes[0].duration), m: Math.round(j.routes[0].distance), geschaetzt: false };
      } catch (e) {}
    }
    const m = Math.round(luftlinieM(start, ziel) * 1.3);
    return { sek: Math.round(m / (modus.kmh / 3.6)), m, geschaetzt: true };
  }
  function navigationsLink(l, modus) {
    if (modus.apple) return "https://maps.apple.com/?daddr=" + l.ort.lat + "," + l.ort.lng + "&dirflg=" + modus.apple;
    return "https://www.google.com/maps/dir/?api=1&destination=" + l.ort.lat + "," + l.ort.lng + "&travelmode=bicycling";
  }
  function bewertungenSuche(l, adresse) {
    const wo = adresse || (l.ort.lat.toFixed(5) + "," + l.ort.lng.toFixed(5));
    return "https://www.google.com/search?hl=de&q=" + encodeURIComponent(l.name + " " + wo + " Bewertungen");
  }

  const Kern = { FARBEN, farbeVon, neuesProfil, codeErzeugen, codeLesen, pruefen, verschluesseln, entschluesseln,
    luftlinieM, dauer, distanz, zeitVor, sollSenden, REGEL, senden, ntfyLesen, neueste, seit,
    bereichAbfrage, overpassLesen, overpassHolen, infosLesen, adresseLesen, MODI, route, navigationsLink, bewertungenSuche, b64url, unb64url };
  global.Kern = Kern;
  if (typeof module !== "undefined") module.exports = Kern;
})(typeof window !== "undefined" ? window : globalThis);
